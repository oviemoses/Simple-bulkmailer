// DE lang variables

tinyMCELang['lang_insert_image_alt2'] = 'Titel des Bildes';
tinyMCELang['lang_insert_image_onmousemove'] = 'Alternatives Bild'
tinyMCELang['lang_insert_image_mouseover'] = 'f&uuml;r Maus dar&uuml;ber';
tinyMCELang['lang_insert_image_mouseout'] = 'f&uuml;r Maus ausserhalb';

// UK lang variables

tinyMCELang['lang_iespell_desc'] = 'Spustit kontrolu pravopisu';
tinyMCELang['lang_iespell_download'] = "ieSpell nedetekov�n. Klikn�te na OK a otev�ete stahovac� str�nku."
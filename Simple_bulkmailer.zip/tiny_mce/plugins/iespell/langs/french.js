// French lang variables by Laurent Dran

tinyMCELang['lang_iespell_desc'] = 'Executer le v&eacute;rificateur d\'orthographe';
tinyMCELang['lang_iespell_download'] = "ieSpell n\'a pas &eacute;t&eacute; trouv&eacute;. Cliquez sur OK pour aller au site de t&eacute;l&eacute;chargement."

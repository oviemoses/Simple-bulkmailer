// IT lang variables

tinyMCELang['lang_iespell_desc'] = 'Avvia il controllo ortografico';
tinyMCELang['lang_iespell_download'] = "ieSpell non trovato. Clicca OK per andare alla pagina di download."

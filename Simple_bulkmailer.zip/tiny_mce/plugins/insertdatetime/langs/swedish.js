// SE lang variables

tinyMCELang['lang_insertdate_desc'] = 'Klistra in datum';
tinyMCELang['lang_inserttime_desc'] = 'Klistra in tid';
tinyMCELang['lang_inserttime_months_long'] = new Array("Januari", "Februari", "Mars", "April", "Maj", "Juni", "Juli", "Augusti", "September", "Oktober", "November", "December");
tinyMCELang['lang_inserttime_months_short'] = new Array("Jan","Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec");
tinyMCELang['lang_inserttime_day_long'] = new Array("S�ndag", "M�ndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "L�rdag", "S�ndag");
tinyMCELang['lang_inserttime_day_short'] = new Array("S�n", "M�n", "Tis", "Ons", "Tor", "Fre", "L�r", "S�n");

// Simplified Chinese lang variables contributed by cube316 (cube316@etang.com)

tinyMCELang['lang_preview_desc'] = 'Ԥ��';

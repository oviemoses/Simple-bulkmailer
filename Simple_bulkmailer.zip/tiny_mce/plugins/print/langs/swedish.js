// SE lang variables

tinyMCELang['lang_print_desc'] = 'Skriv ut';
